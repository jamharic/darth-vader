<head>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

</head>
 <a class="navbar-brand" href="index.php"><img src="images/testlogo.png" width="70px" height="70px"></a>
<div class="container-fluid">
    <div class="navbar-header">
   
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">ADS Page</a></li>
        <li><a href="help.php">How To Use</a></li>
        <li><a href="farmcare.php">FarmCare</a></li>
        
      </ul>
      
    </div>
  </div>