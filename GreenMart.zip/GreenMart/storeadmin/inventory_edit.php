<?php 
//login admin
session_start();
if(!isset($_SESSION["manager"])){//if manager not logged in yet
	header("location:admin_login.php");
	exit();
	}
$managerID=preg_replace('#[^0-9]#i','',$_SESSION["id"]);//filter everything but numbers
$manager=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["manager"]);//filter everything but numbers and letters
$password=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["password"]);//filter everything but letters
include"../storescripts/connect_to_mysql.php";
$sql=mysql_query("SELECT * FROM admin WHERE  id='$managerID' AND username='$manager' AND password='$password' LIMIT 1");//make sure person exist
$existCount=mysql_num_rows($sql);
if($existCount == 0){
	echo "Your login session data is not on record in the database";
	exit();
		}
?>
<?php 
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors','1');
?>
<?php 
//parse the form data and add inventory item to the system
if(isset($_POST['product_name'])){	
$pid=mysql_real_escape_string($_POST['thisID']);
$product_name=mysql_real_escape_string($_POST['product_name']);
$price=mysql_real_escape_string($_POST['price']);
$category=mysql_real_escape_string($_POST['category']);
$subcategory=mysql_real_escape_string($_POST['subcategory']);
$details=mysql_real_escape_string($_POST['details']);
//see if that product_name is an identical match to another product in the system
$sql=mysql_query("UPDATE products SET product_name='$product_name', price='$price', category='$category', subcategory='$subcategory', details='$details' WHERE id='$pid'");
	if($_FILES['product_image']['tmp_name']!=""){
	
	//place image in the folder
	$newname="$pid.jpg";
	move_uploaded_file($_FILES['product_image']['tmp_name'],"../inventory_images/$newname");
	}
	header("location:inventory_list.php");
	exit();
}
?>
<?php 
//Gather this products full info for inserting automatically into the edit form
if(isset($_GET['pid'])){
$targetID=$_GET['pid'];
$sql=mysql_query("SELECT * FROM products WHERE id='$targetID' LIMIT 1");
$productCount=mysql_num_rows($sql);//count the output amount
if($productCount>0){
	while($row=mysql_fetch_array($sql)){	
		 $product_name=$row["product_name"];
		 $price=$row["price"];
		 $category=$row["category"];
		 $subcategory=$row["subcategory"];
		 $details=$row["details"];
		 $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
  }
}
else{
echo "Sorry that product doesn`t exist!!!";
exit();
}
}
?>
 <html>
<head>
 <title>Inventory List</title>
<link rel="stylesheet" href="../style/style.css" type="text
/css" media="screen"/>
</head>
 <body>
 <div id="mainWrapper" align="center">
   <table border="0" width="1000px">
<tr>
<td>
<?php include_once("template_header.php");?>
</td>
</tr>
</table>
   <div id="pageContent"><br/>
     <div align="right" style="margin-right:32px;"><a href="inventory_list.php#inventoryForm">+ Add New Inventory Item</a></div>
<div align="left" style="margin-left:24px;">
      <h2>Inventory List</h2>     
</div>
<a name="inventoryForm"id="inventoryForm"></a>
<h3>Add New Inventory Item Form</h3>
<form action="inventory_edit.php" enctype="multipart/form-data" name="myForm" id="myForm" method="post">
<table width="90%"border="0"cellspacing="0"cellpadding="6px">
<tr>
<td width="20%" align="right">Product Name</td>
<td width="80%">
  <input type="text" name="product_name" id="product_name"size="64" value="<?php echo $product_name; ?>">
</td>
</tr>
<tr>
<td align="right">Product Price</td>
<td>
   $
     <input type="text" name="price" id="price"size="12" value="<?php echo $price; ?>">
</td>
</tr>
<tr>
<td align="right">Category</td>
<td>
<select name="category" id="category">
<option value="Clothing">Clothing</option>
</select>
</td>
</tr>
<tr>
<td align="right">Subcategories</td>
<td>
<select name="subcategory" id="subcategory">
<option value="<?php echo $subcategory; ?>"><?php echo $subcategory; ?></option>
<option value="Blouse">Blouse</option>
<option value="Hats">Hats</option>
<option value="Jackets">Jackets</option>
<option value="Pants">Pants</option>
<option value="Shirts">Shirts</option>
<option value="Shoes">Shoes</option>
<option value="Shorts">Shorts</option>
<option value="Skirts">Skirts</option> 
<option value="Socks">Socks</option>
<option value="Suits">Suits</option>
<option value="T-Shirts">T-Shirts</option>
</select></td>
</tr>
<tr>
  <td align="right">Product Details</td>
  <td>
    <textarea name="details" id="product_details" cols="64" rows="5"><?php echo $details; ?></textarea>
</td>
</tr>
<tr>
  <td height="60" align="right">product Image</td>
  <td>
    <input type="file" name="product_image" id="product_image">
</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>
<input name="thisID" type="hidden" value="<?php echo $targetID; ?>">
  <input type="submit" name="add_items" id="add_items" value="Edit Item ">
</td>
</tr>
</table>
</form>
<br/>
<a href="inventory_list.php"><-Go back</a>
<br/>
<br/>
</div>
  <table border="0" width="1000px">
<tr>
<td>
<?php include_once("../template_footer.php");?>
</td>
</tr>
</table>
 </div>
 </body>
 </html>