<link rel="stylesheet" href="../style/style.css" type="text/css"/>
<style type="text/css">

<!--

ul{
				list-style-type: none;
				font-size:9pt;
  }
ul#navmenu li{
	 width: 125px;
	 text-align:center;
	 position:relative;
	 float:left;
	 margin-right:4px;
			 }
ul#navmenu a{
     text-decoration:none;
	 display:block;
	 width: 125px;
	 height: 25px;
	 line-height:25px;
	 background-color:#CCF;
	 border:1px solid #CCC;
	 border-radius: 5px;
}	
ul#navmenu .sub1 a{
     margin-top:3px;	
}
ul#navmenu .sub2 a{
     margin-left:8px;	
}
ul#navmenu li:hover > a{
     background-color:#CFC;	
}
ul#navmenu li:hover a:hover{
     background-color:#FF0;	
}
ul#navmenu ul.sub1{
     display:none;
	 position:absolute;
	 top:26px;
	 left:0px;
}
ul#navmenu ul.sub2{
     display:none;
	 position:absolute;
	 top:0px;
	 left:85px;
}
ul#navmenu li:hover .sub1{
     display:block;
}
ul#navmenu .sub1 li:hover .sub2{
     display:block;
}
.darrow{
font-size:9pt;
position:absolute;
top:5px;
right:4px;
color:#000;
}
.rarrow{
font-size:9pt;
position:absolute;
top:7px;
right:4px;
color:#000;
}
-->
</style>
<img src="images/icon.png" height="50px" width="50px"/>
   <table>
     
     <tr>
     
       <td height="0" colspan="3" valign="top"><ul id="navmenu">
  <li><a href="index.php">home</a></li>
 <li><a href="about.php">about us</a>
  </li>
 
  <li><a href="product_list.php">produce</a><span class="darrow">&#9660;</span>
   
      
  </li>
  <li><a href="Aggrovet.php">Online Aggrovet</a></li>
  <li><a href="logout.php">Log Out</a></li>
 </ul> 
 </td>
     </tr>
   </table>
 