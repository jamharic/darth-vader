<head>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
</head>
<a href="index.php"><img src="images/testlogo.png" height="50px" width="100px"/></a>
   <table>
     
     <tr>
     
       <td height="0" colspan="3" valign="top" align="center"><ul id="navmenu">
 
 
 
  
   
      
<div class="container">
   
    <div class="nav nav nav-tabs nav-justified"> 
<li class="active navbar-btn"><a href="index.php">AD's Page</a></li>
 <li class="active"><a href="help.php">How To Use</a>
  </li>
 
  <li class="active"><a href="farmcare.php">Farmcare</a>
   
      
  
  </li>
  
  </div>
  </div>
</ul>
  

 </td>
 
     </tr>
   </table>
  
   

 