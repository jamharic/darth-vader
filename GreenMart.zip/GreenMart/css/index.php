<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>OOOPs!!!</title>
<style>
body{
background-color:#CCC;	
	
	
	}
#error{
	border-color:#000;
	width:200px;
	height:200px;
	margin-left:450px;
	margin-top:300px;
	
	}

	
	
	
	

</style>
</head>

<body>
<div id="error">
<h1>OOps!!!</h1><h3>Nice  Try</h3>
<a href="../index.php"><h2 align="centre">GO BACK</h2></a>
</div>

</body>
</html>