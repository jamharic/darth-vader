<head>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

</head>
 
<div class="container-fluid">
    <div class="navbar-header">
   
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="index.php">ADS Page</a></li>
        <li><a href="help.php">How To Use</a></li>
        <li><a href="farmcare.php">FarmCare</a></li>
        
      </ul>
      
    </div>
  </div>

<div class="row">
        <div class="col-sm-6 col-sm-offset-3">
       <form action="search.php" method="post">
     <div id="imaginary_container"> 
                <div class="input-group stylish-input-group">
                 
                    <input type="text" class="form-control" name="search" placeholder="Search" value="<?php echo $_REQUEST['search'];?>" >
                    <span class="input-group-addon">
                        <button type="submit" name="submit">
                            <span class="glyphicon glyphicon-search"></span>
                        </button>  
                    </span>
                   
                </div>
            </div>
    </form>
    </div>
	</div>
   




 