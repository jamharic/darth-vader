<head>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
</head>
<a href="index.php"><img src="images/testlogo.png" height="70px" width="70px"/></a>
   <table>
     
     <tr>
     
       <td height="0" colspan="3" valign="top" align="center">
 
 
 
  
   
      
<div class="container">
<div class="row">
        <div class="col-sm-6 col-sm-offset-3">
       <form action="search.php" method="post">
     <div id="imaginary_container"> 
                <div class="input-group stylish-input-group">
                 
                    <input type="text" class="form-control" name="search" placeholder="Search" value="<?php echo $_REQUEST['search'];?>" >
                    <span class="input-group-addon">
                        <button type="submit" name="submit">
                            <span class="glyphicon glyphicon-search"></span>
                        </button>  
                    </span>
                   
                </div>
            </div>
    </form>
    </div>
</div>
   
   
  </div>
</ul>
  

 </td>
 
     </tr>
   </table>
  
   

 