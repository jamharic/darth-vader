<?php 

include"sscripts/connect_to_mysql.php";
$dynamicList="";
$sql=mysql_query("SELECT * FROM products ORDER BY id DESC ");
$productCount=mysql_num_rows($sql);
if($productCount>0){
	while($row=mysql_fetch_array($sql)){
	     $id=$row["id"];	
		 $product_name=$row["prod_name"];
		 $price=$row["price"];
		 $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
$dynamicList.='<table class="col-sm-6">
<tr>
<td width="90"><a href="product.php?id='.$id.'"><img style="border:#666 1px solid"src="inventory_images/'.$id.'.jpg" width="86" height="90"></a></td>
<td width="150" valign="top"><p>'.$product_name.'<br>
Ksh'.$price.'<br>
<a href="product.php?id='.$id.'">View Product Details</a></p></td>
</tr>
</table><br/> 
</td>
<td width="100" valign="top">&nbsp;</td>
</tr>
</table>';
  }
}
else{
$dynamicList="no products listed yet";
}
mysql_close();
?>
<html>
<head>
<title>.::Green-Mart</title>
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen"/>
<style type="text/css"> 
<!--
body tr td h3 {
	color: #F00;
}
-->
</style>
</head>
<body>
<nav class="nav navbar-inverse navbar-fixed-top">

<?php include_once("head.php");?>
</nav>

   <div style="padding-top:12%;"></div>
<div class="container">


      <p align="center"><?php echo $dynamicList; ?></p>
      <p align="center"><a href="index.php">click here to view less items</a></p>
      
      </div>
      
      
<div class="modal-footer">

<?php include_once("footer.php");?>

</div>
 </body>
 </html>