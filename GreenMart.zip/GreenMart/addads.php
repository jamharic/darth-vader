<?php 
 

error_reporting(E_ALL);
ini_set('display_errors','1');
?>


<?php 
include_once('sscripts/connect_to_mysql.php');

if(isset($_POST['product_name'])){	
$product_name=($_POST['product_name']);
$phone=($_POST['phone']);
$price=($_POST['price']);
$category=($_POST['category']);
$subcategory=($_POST['subcategory']);
$details=($_POST['details']);
$location=($_POST['location']);



	
	$sqlin = "insert into products  (prod_name,price,details,category,date_added,PhoneNo,Location) values ('".$product_name."','".$price."','".$details."','".$category."',now(),'".$phone."','".$location."')";
	mysql_query($sqlin)or die(mysql_error());
	$pid=mysql_insert_id();
	
	$newname="$pid.jpg";
	move_uploaded_file($_FILES['product_image']['tmp_name'],"inventory_images/$newname");
	?><script type="text/javascript">
    alert("Your product has susscesfully been added to GreenMart");
    </script>
    <?php
	header("location:addads.php");
	exit();
	
	}
?>



 <html>
<head>
 <title>.::postads</title>
<link href="style/style.css" rel="stylesheet" type="text/css">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
</head>
 <body>
 <nav class="nav navbar-inverse navbar-fixed-top">
<?php include_once("head.php");?>
</nav>
<br>
&nbsp;
 
    

<div style="padding-top:10%"></div>
<div class="modal-content">
<br>
<h1 align="center"> POST THE AD HERE</h1>
<form action="addads.php" class="form-horizontal" align="center" enctype="multipart/form-data" name="myForm" id="myForm" method="post">

<div class="form-group">
    
    <div class="col-sm-10">
  <input type="text"  class="form-control"  name="product_name" id="product_name" placeholder="product name" required>
</div>
</div>
<div class="form-group">
    
    <div class="col-sm-10">
  <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone Number" required>
</div>
</div>
<div class="form-group">
    
    <div class="col-sm-10">
  <input type="text" class="form-control" name="price" id="price" placeholder="Price" required>
</div>
</div>
<div class="form-group">
    
    <div class="col-sm-10">
   <input type="text" class="form-control" name="location" id="location"  placeholder="e.g County,subcounty" required>
</div>
</div>
<div class="form-group">
    
    <div class="col-sm-10">
<select class="form-control"  name="category" id="category">
<option value="Farm Product">Farm Product</option>
<option value="Animal Product"> Animal Product</option>
</select>
</div>
</div>
<div class="form-group">
    
    <div class="col-sm-10">
 
    <textarea name="details" placeholder="Additional product Details" class="form-control" id="product_details"  rows="5" required></textarea>
</div>
</div>
 <div class="form-group class="col-sm-10"">
     
      <label class="btn btn-primary">
    <input type="file" class="form-control" name="product_image" id="product_image" required>
</label>
</div>
<div class="form-group">
    
    <div class="col-sm-10">
  <input type="submit" class="btn btn-default"  name="add_items" id="add_items" value="Post AD">
</div>
</div>

</form>
</div>
</div>


<div class="modal-footer">
<?php
include_once "footer.php";
?>
</div>
 

 </body>
 </html>