<?php 
error_reporting(0);

include('sscripts/connect_to_mysql.php');
require_once('AfricasTalkingGateway.php');

if(isset($_GET['id'])){
include"sscripts/connect_to_mysql.php";
$id=preg_replace('#[^0-9]#i','',$_GET['id']);

$sql=mysql_query("SELECT * FROM products WHERE id='$id' LIMIT 1");
$productCount=mysql_num_rows($sql);
if($productCount>0){
  
while($row=mysql_fetch_array($sql)){  
     $product_name=$row["prod_name"];
     $price=$row["price"];
     $details=$row["details"];
     $category=$row["category"];
     
     $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
     $PhoneNo=$row["PhoneNO"];
     $Location=$row["Location"];
  }
}else{
   echo "That item doesn`t exist.";
   exit();
}
mysql_close();
}


if(isset($_POST['name'])){	
include('sscripts/connect_to_mysql.php');
$name=($_POST['name']);
$phone=($_POST['phone']);
$date=date('Y-m-d');
$loc=($_POST['location']);
$quantity=($_POST['quantity']);
	
	$sqlin = "insert into customers  (name,date,phone,location,quantity) values ('".$name."',now(),'".$phone."','".$loc."','".$quantity."')";
	mysql_query($sqlin)or die(mysql_error());
	$id=mysql_insert_id();
	echo 'Order Successfully submitted. Please await confirmation from the farmer on your order!';

    $username   = "jamharic";
    $apikey     = "e80936d2e709a7809af13e3e41b1f8b666c078d715a432ef41073896e2bf4456";
    $farmer = $PhoneNo;
    $customer = $phone;

    $message    = "Hello, This is to inform you that the following customer has ordered your product....Name:".$name.",phone number:".$phone.",location:".$loc.". Thank you for using green mart and your welcomed to market more of your products to customers all around the world.";
    
    $message1    = "Hello ".$name.", This is to inform you that your order for ".$product_name." was successful. Product details are Price: Kshs. ".$price.",Details:".$subcategory." ".$category.",quantity:".$details.", Phone number:".$PhoneNo.", Location:".$Location.". Thank you for using green mart and your welcomed to get more of farm products.";

    $gateway    = new AfricasTalkingGateway($username, $apikey);
    
    try 
    { 
      // Thats it, hit send and we'll take care of the rest. 
      $results = $gateway->sendMessage($farmer, $message);
      $res = $gateway->sendMessage($customer, $message1);
                
      foreach($results as $result) {
        // status is either "Success" or "error message"
      /*  echo " Number: " .$result->number;
        echo " Status: " .$result->status;
        echo " MessageId: " .$result->messageId;
        echo " Cost: "   .$result->cost."\n";
        */
      }
    }
    catch ( AfricasTalkingGatewayException $e )
    {
     echo "Encountered an error while sending: ".$e->getMessage();
    }
    // DONE!!! 

	header("Refresh:5; url=index.php"); 
	exit();
	}
?>



 <html>
<head>
 <title>.::Order Product</title>
<link href="style/style.css" rel="stylesheet" type="text/css">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">

</head>
 <body>
 <nav class="nav navbar-inverse navbar-fixed-top">
<?php include_once("heading.php");?>
</nav>

 
    



<div class="modal-content" style="padding-top:12%; padding-bottom:12%;">
  <table class="modal-content" style="margin:auto;">
    <tr>
      <td width="172"><p><a href="inventory_images/<?php echo $id; ?>.jpg"><img src="inventory_images/<?php echo $id; ?>.jpg" width="148" height="123" alt="<?php echo $product_name; ?>"></a></p>
        <p><a target="blank" href="inventory_images/<?php echo $id; ?>.jpg">View Full Size Image</a></p></td>
      <td width="625" valign="top"><strong style=" font-weight:500px; text-transform:uppercase;font-size:16px;color:#600"><?php echo $product_name; ?></strong><br>
        <?php echo "ksh : ".$price; ?><br>
          <?php echo "$category"; ?><br>
          <?php echo $details; ?><br>
      <span style="color:#03F;"><?php echo "Call : ".$PhoneNo; ?></span><br>
           <span style="color:#666;"><?php echo "Location : ".$Location; ?></span><br>
            <span style="color:#03F;"><?php echo "Added On : ".$date_added; ?></span><br>
          
        </td>
    </tr>
  </table>




<br>
<h1 align="center"> Order Product</h1>

<form class="form-horizontal" action="order.php?id=<?php echo $_REQUEST['id']?>" enctype="multipart/form-data" name="myForm" id="myForm" method="post">
  <div class="form-group">
   
    <div class="col-sm-10">
      <input type="text" name="name" class="form-control" id="name" placeholder="Enter Name" required>
    </div>
  </div>
  <div class="form-group">
    
    <div class="col-sm-10"> 
      <input type="text" class="form-control" name="location" id="location" placeholder="Enter Your Location" required>
    </div>
  </div>
  <div class="form-group">
    
    <div class="col-sm-10"> 
      <input type="text" class="form-control" name="phone" id="phoneno" placeholder="Enter Phone number" required>
    </div>
  </div>
   <div class="form-group">
    
    <div class="col-sm-10"> 
      <input type="text" class="form-control" name="quantity" id="quantity" placeholder="Enter the Order Quantity" required>
    </div>
  </div>
  
  <div class="form-group"> 
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default" name="order" id="order">Submit Order</button>
    </div>
  </div>
</form>




 </div>


<div class="modal-footer">
<?php
include_once "footer.php";
?>
</div>
 </body>
 </html>