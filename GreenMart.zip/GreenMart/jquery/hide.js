$(document).ready(function() {

    $(".slidingDiv").hide();
    $("#show_hide").show();

    $("#show_hide").click(function(){
        var $str = $(this).attr("id");
        var $index = $str.replace('show_hide', '');


        var divName = ".slidingDiv" + $index;
        $(divName).slideToggle();

    });

});