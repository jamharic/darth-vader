<html>
<head>
<title>GreenMart</title>
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen"/>
<link href="images/testlogo.png" rel="icon" type="image/icon"/>
</head>
<body>

<nav class="nav navbar-inverse navbar-fixed-top">
<?php include_once("head.php");?>
</nav>
<div style="padding-top:12%;"></div>

<div class="modal-content">


     <p> <h3 style="text-decoration:underline;">It`s so easy to use and follows this steps:</h3></p>
      <p>1. Click on the product you want to purchase on the <span style="color:#00F; text-decoration:underline;">view product link</span></p>
      <p>2. Click on <span style="color:#00F; text-decoration:underline;"> Order Button</span></p>
      <p>3. This will take you to the Order Page</p>
      <p>4. Follow the prompts </p>
      <p>You will recieve a notifaction.</p>
     

</div>

<div class="modal-footer">
<?php include_once "footer.php";?>

</div>
</body>

 </html>