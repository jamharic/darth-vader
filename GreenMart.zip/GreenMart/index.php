<?php 
error_reporting (0);
include"sscripts/connect_to_mysql.php";
$dynamicList="";
$sql=mysql_query("SELECT * FROM products ORDER BY id DESC LIMIT 8");
$productCount=mysql_num_rows($sql);
if($productCount>0){
	while($row=mysql_fetch_array($sql)){
	     $id=$row["id"];	
		 $product_name=$row["prod_name"];
		 $price=$row["price"];
		 $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
$dynamicList.='<table class="col-sm-6" style="border: 1px #0000FF;">
<tr>
<td ><a href="product.php?id='.$id.'"><img style="padding:15px;"src="inventory_images/'.$id.'.jpg" width="100" height="100"></a></td>
<td  valign="top"><p>'.$product_name.'<br>
Ksh'.$price.'<br>
<a href="product.php?id='.$id.'">View Product Details</a><br>
<a href="order.php?id='.$id.'"><button style="background-color:#ff9600;color:white;border-radius:5px;">Order Now</button></a></p></td>
</tr>
</table><br>
</td>
<td width="100" valign="top">&nbsp;</td>
</tr>
</table>';
  }
}
else{
$dynamicList="No products are listed in our store yet";
}
mysql_close();
?>
<html>
<head>
<title>::Green-Mart</title>
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">


<link href="images/testlogo.png" rel="icon" type="image/icon"/>
</head>

<nav class="nav navbar-inverse navbar-fixed-top">
<a class="navbar-brand" href="index.php"><img src="images/testlogo.png" width="70px" height="70px"></a>
<?php include_once("header.php");?>

</nav>

<div style="padding-top:10%;"></div>
<div class="container">

<div class="modal-content">

<?php echo $dynamicList; ?>

<a href="index1.php">click here to view more</a>
<section id="sidebar">
<a href="addads.php"><small>POST AD</small></a>
</section>
</div>
</div>
 </body>
 <div class="modal-footer">
 <?php
 include_once "footer.php";
 ?>
 </div>
 </html>