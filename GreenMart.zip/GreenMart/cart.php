<?php 
session_start();
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors','1');
include"sscripts/connect_to_mysql.php";
?>
<?php 
//push items into array
if(isset($_POST['pid'])){
	$pid=$_POST['pid'];
	$wasFound=false;
	$i=0;
	//if the cart session variable is not set or cart array is empty
	if(!isset($_SESSION["cart_array"]) || count($_SESSION["cart_array"])<1){
		//run if the cart is empty or not set
		$_SESSION["cart_array"]=array(0=>array("item_id"=>$pid,"quantity"=>1));
     }else{
	  //Run if cart has atleast one item in it
	  foreach($_SESSION["cart_array"]as $each_item){
		  $i++;
		  while(list($key,$value)=each($each_item)){
			 if($key=="item_id"&&$value==$pid){
			//that item is in the cart adjust quantity using array_splice()
			array_splice($_SESSION["cart_array"],$i-1,1,array(array("item_id"=>$pid,"quantity"=>$each_item['quantity']+1)));
			$wasFound=true;
		    } //close if condition
	     }//close while loop
	  }//close foreach loop
	  if($wasFound==false){
		  array_push($_SESSION["cart_array"],array("item_id"=>$pid,"quantity"=>1));
	  }
   }
   header("location:cart.php");
	exit();
}
?>
<?php 
// if user chooses to empty cart
if(isset($_GET['cmd'])&&$_GET['cmd']=="emptycart"){
	unset($_SESSION["cart_array"]);
}
?>
<?php 
// if user chooses to adjust item quantity
if(isset($_POST['item_to_adjust'])&&$_POST['item_to_adjust']!=""){
	$item_to_adjust=$_POST['item_to_adjust'];
	$quantity=$_POST['quantity'];
	$quantity=preg_replace('#[^0-9]#i','',$quantity);//filter everything but numbers
	if($quantity>=100){
	$quantity=99;	
	}
	if($quantity<1){
	$quantity=1;	
	}
	$i=0;
  foreach($_SESSION["cart_array"]as $each_item){
		  $i++;
		  while(list($key,$value)=each($each_item)){
			 if($key =="item_id"&&$value==$item_to_adjust){
			//that item is in the cart adjust quantity using array_splice()
			array_splice($_SESSION["cart_array"],$i-1,1,array(array("item_id"=>$item_to_adjust,"quantity"=>$quantity)));
		    } //close if condition
	     }//close while loop
	  }//close foreach loop
}
?>
<?php 
//To remove item from cart
if(isset($_POST['index_to_remove'])&&$_POST['index_to_remove']!=""){
	//Access the array and run code to remove that array index
$key_to_remove=$_POST['index_to_remove'];
	if(count($_SESSION["cart_array"])<=1){
		unset($_SESSION["cart_array"]);
	}else{
		unset($_SESSION["cart_array"]["$key_to_remove"]);
		sort($_SESSION["cart_array"]);
	}
}
?>
<?php 
//render cart for user to view
$cartOutput="";
$cartTotal=""; 
$pp_checkout_btn=''; 
$product_id_array='';
if(!isset($_SESSION["cart_array"]) || count($_SESSION["cart_array"])<1){
  $cartOutput="<h2 align='center'>Your shopping cart is empty</h2>";		
}else{
	//start paypal checkout button
	$pp_checkout_btn.='<form action="http://www.paypal.com/cgi-bin/websrc" method="post">
	<input name="cmd" type="hidden" value="_cart">
	<input name="upload" type="hidden" value="1">
	<input name="business" type="hidden" value="jamharic01@gmail.com">';
	//start foreach loop
	  $i=0;
	  foreach($_SESSION["cart_array"]as $each_item){
		  $item_id=$each_item['item_id'];
		  $sql=mysql_query("SELECT * FROM products WHERE id='$item_id' LIMIT 1");
		  while($row=mysql_fetch_array($sql)){
		  	$product_name=$row["product_name"];
			$price=$row["price"];
			$details=$row['details'];
	     }
		  $pricetotal=$price * $each_item['quantity'];
		  $cartTotal=$pricetotal + $cartTotal;
		 
		  setlocale(LC_MONETARY,"en_US");
		  $price=number_format($price, 2);
		  echo "$".$price;
	      $pricetotal=number_format($pricetotal, 2);
		  echo "$".$pricetotal;
		  //Dynamic checkout button assembly
		  $X=$i+1;
		  $pp_checkout_btn.='<input name="item_name_'.$X.'" type="hidden" value="'.$product_name.'">
		  <input name="amount_'.$X.'" type="hidden" value="'.$price.'">
		  <input name="quantity_'.$X.'" type="hidden" value="'.$each_item['quantity'].'">';
		  $product_id_array.="$item_id-".$each_item['quantity']." , ";
		  //Dynamic table row assembly
		   $cartOutput.="<tr>";
		   $cartOutput.="<td><a href=\"product.php?id=$item_id\">$product_name</a><br/><a href=\"product.php?id=$item_id\" ><img src=\"inventory_images/$item_id.jpg\" alt=\"$product_name\"width=\"50\"height=\"52\"border=\"1\"class=\"img1\"/></a></td>";
		   $cartOutput.='<td>'.$details.'</td>';
		   $cartOutput.='<td>$'.$price."</td>";
		   $cartOutput.='<td><form action="cart.php" method="post">
		   <input name="quantity" type="text"size="1"maxlength="2"value="'.$each_item['quantity'].'">
		   <input name="adjustBtn'.$item_id.'"type="submit"value="change"/>
		   <input name="item_to_adjust" type="hidden" value="'.$item_id.'">
		   </form></td>';
		  // $cartOutput.='<td>'.$each_item['quantity'].'</td>';
		   $cartOutput.='<td>$'.$pricetotal.'</td>';
	       $cartOutput.='<td><form action="cart.php" method="post"><input name="deleteBtn'.$item_id.'"type="submit"value="X"/>
		   <input name="index_to_remove" type="hidden" value="'.$i.'"></form></td>';
	       $cartOutput.='</tr>'; //while(list($key,$value)=each($each_item)){
			 //$cartOutput.="$key: $value<br/>";
	 // }
	 $i++;
   }
          setlocale(LC_MONETARY,"en_US");
		  $cartTotal=number_format($cartTotal, 2);
		  echo "$".$cartTotal;
   $cartTotal="Cart Total : $".$cartTotal." USD";
   //finish paypal checkoutbtn
   $pp_checkout_btn.='<input name="custom" type="hidden" value="'.$product_id_array.'">
   <input name="notify_url" type="hidden" value="https://localhost/ecommerce/storescripts/my_ipn.php">
   <input name="rm" type="hidden" value="2">
   <input name="cbt" type="hidden" value="Return to The Store">
   <input name="cancel_return" type="hidden" value="https://localhost/ecommerce/paypal_cancel.php">
   <input name="Ic" type="hidden" value="US">
   <input name="currency_code" type="hidden" value="USD">
   <input name="submit" type="image" src="images/paypal.png" alt="Make payment with PayPal.Its fast, free and secure"width="150"height="90">
   </form>';
}
?>
<html>
<head>
<title>Your Cart</title>
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen"/>
</head>
<body>
<div id="mainWrapper" align="center">
<table border="0" width="1000px">
<tr>
<td>
<nav class="fixed-nav-bar">
<?php include_once("header.php");?>
</nav>
</td>
</tr>
</table>
<div id="dcart">
<div align="right" style="margin-right:32px;margin-top:24px;margin-bottom:5px;"><a href="product_list.php">+ Add another Item</a></div>
  <div style="margin-left:24px;margin-right:24px;margin-bottom:24px;margin-top:0px; text-align:left;">
  <br/>
  <table width="100%" border="1" cellpadding="6" cellspacing="0">
    <tr bgcolor="#FFFFFF">
      <td width="18%" bgcolor="#00CC33"><strong>Product</strong></td>
      <td width="45%" bgcolor="#00CC33"><strong>Product Description</strong></td>
      <td width="12%" bgcolor="#00CC33"><strong>Unit Price</strong></td>
      <td width="9%" bgcolor="#00CC33"><strong>Quantity</strong></td>
      <td width="7%" bgcolor="#00CC33"><strong>Total</strong></td>
      <td width="9%" bgcolor="#00CC33"><strong>Remove</strong></td>
    </tr>
     <?php echo $cartOutput; ?>
  </table>
  <br/>
  <a href="cart.php?cmd=emptycart">Click Here to Empty Your Shopping Cart</a>
  <span style="float:right; color:#00F;"><?php echo $cartTotal; ?></span>
  <br/>
  <br/>
 <div align="right"> <?php echo $pp_checkout_btn; ?></div>
</div>  <br/>



</div>
<div id="pageFooter">
<?php
include_once("footer.php")
?>
</div>
</body>
</html>