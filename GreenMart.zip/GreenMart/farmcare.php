<?php 

include"sscripts/connect_to_mysql.php";
$dynamicList="";
$sql=mysql_query("SELECT * FROM fcproducts ORDER BY id DESC");
$productCount=mysql_num_rows($sql);
if($productCount>0){
	while($row=mysql_fetch_array($sql)){
	     $id=$row["id"];	
		 $product_name=$row["prod_name"];
		 $price=$row["price"];
		 $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
$dynamicList.='<table>
<tr>
<td width="90"><a href="productfc.php?id='.$id.'"><img style="border:#666 1px solid"src="fc_images/'.$id.'.jpg" width="86" height="90"></a></td>
<td width="150" valign="top"><p>'.$product_name.'<br>
ksh'.$price.'<br>
<a href="fcproduct.php?id='.$id.'">View Product Details</a><br>
<a href="order.php?id='.$id.'"><button style="background-color:#ff9600;color:white;border-radius:5px;">Order Now</button></a></p></td>
</p></td>
</tr>
</table><br/> 
</td>
<td width="100" valign="top">&nbsp;</td>
</tr>
</table>';
  }
}
else{
$dynamicList="You have no new products listed in your store yet";
}
mysql_close();
?>
<html>
<head>
<title>.::productspage</title>
<link rel="stylesheet" href="style/style.css" type="text/css" media="screen"/>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" media="screen"/>
<style type="text/css">
<!--
body tr td h3 {
	color: #F00;
}
-->
</style>
</head>
<body>

<div style="padding-top:10%;">
<nav class="nav navbar-inverse navbar-fixed-top">
<?php include_once("head.php");?>
</nav>

<div class="modal-content" >
&nbsp;

      <p align="center" style="padding-left:20px;"><?php echo $dynamicList; ?></p>
      
</div>


<div class="modal-footer">
 <?php
 include_once "footer.php";
 ?>
</div>
 </body>
 </html>