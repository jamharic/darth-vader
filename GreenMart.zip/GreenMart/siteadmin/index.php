<?php 
session_start();
if(!isset($_SESSION["manager"])){
	header("location:admin_login.php");
	exit();
	}
$managerID=preg_replace('#[^0-9]#i','',$_SESSION["id"]);
$manager=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["manager"]);
$password=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["password"]);
include"../sscripts/connect_to_mysql.php";
$sql=mysql_query("SELECT id FROM admin WHERE  id='$managerID' AND username='$manager' AND password='$password' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount == 0){
	header("location:../index.php");
	exit();
		}
?>
 <html>
<head>
 <title>Store Admin Area</title>
<link rel="stylesheet" href="../style/style.css" type="text
/css" media="screen"/>;
</head>
 <body>
 
  
   <div id="dinv"><br/>
     <div align="left" style="margin-left:24px;">
     <h2>Hello sir, what would you like to do today?</h2> 
       <p><a href="inventory_list.php">Manage The Page</a><br/></p>
       
     </div>
</div>
  
 
 </body>
 </html>