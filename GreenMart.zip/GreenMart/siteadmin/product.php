<?php 
//Error Reporting
error_reporting(E_ALL);
ini_set('display_errors','1');
?>
<?php 
//check to see URL variable is set and exists in db
if(isset($_GET['id'])){
include"../storescripts/connect_to_mysql.php";
$id=preg_replace('#[^0-9]#i','',$_GET['id']);
//Use this variable to check if the ID exists, if yes get the product
//details, if no then exit script and give msg why
$sql=mysql_query("SELECT * FROM products WHERE id='$id' LIMIT 1");
$productCount=mysql_num_rows($sql);//count the output amount
if($productCount>0){
	//get all the product details
while($row=mysql_fetch_array($sql)){	
		 $product_name=$row["product_name"];
		 $price=$row["price"];
		 $details=$row["details"];
		 $category=$row["category"];
		 $subcategory=$row["subcategory"];
		 $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
  }
}else{
	 echo "That item doesn`t exist.";
	 exit();
}
mysql_close();
}
?>
<html>
<head>
<title><?php echo $product_name; ?></title>
<link rel="stylesheet" href="../style/style.css" type="text/css" media="screen"/>
<style type="text/css">
<!--
body tr td h3 {
	color: #F00;
}
.td {
	color: #800040;
}
-->
</style>
</head>
<body>
<div id="mainWrapper" align="center">
<table border="0" width="1000px">
<tr>
<td>
<?php include_once("template_header1.php");?>
</td>
</tr>
</table>
<div id="pageContent">
  <table width="100%" border="0" cellpadding="15">
    <tr>
      <td width="172"><p><a href="../inventory_images/<?php echo $id; ?>.jpg"><img src="../inventory_images/<?php echo $id; ?>.jpg" width="148" height="123" alt="<?php echo $product_name; ?>"></a></p>
        <p><a href="../inventory_images/<?php echo $id; ?>.jpg">View Full Size Image</a></p></td>
      <td width="625" valign="top"><strong style=" font-weight:500px; text-transform:uppercase;font-size:16px;color:#600"><?php echo $product_name; ?></strong><br>
        <?php echo "$".$price; ?><br>
          <?php echo "$subcategory $category"; ?><br>
          <?php echo $details; ?><br>
          <form id="form1"name="form1"method="post"action="cart.php">
          <input type="hidden"name="pid"id="pid"value="<?php echo $id;?>"/>
          <input type="submit"name="button"id="button"value="Add to Shopping Cart"/>
          </form>
        </td>
    </tr>
  </table>
</div>
<table border="0" width="1000px">
<tr>
<td>
<?php include_once("../template_footer.php");?>
</td>
</tr>
</table>
</div>
 </body>
 </html>