<?php 

session_start();
if(!isset($_SESSION["manager"])){
	header("location:admin_login.php");
	exit();
	}
$managerID=preg_replace('#[^0-9]#i','',$_SESSION["id"]);
$manager=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["manager"]); 
$password=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["password"]);
include"../sscripts/connect_to_mysql.php";
$sql=mysql_query("SELECT * FROM admin WHERE  id='$managerID' AND username='$manager' AND password='$password' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount == 0){
	echo "Your login session data is not on record in the database";
	exit();
		}
?>
<?php 

error_reporting(E_ALL);
ini_set('display_errors','1');
?>
<?php 

if(isset($_GET['deleteid'])){
	 echo "Do you really want to delete product with ID of ".$_GET['deleteid']."? <a href='inventory_list.php?yesdelete=".$_GET['deleteid']."'>Yes</a>|<a href='inventory_list.php'>NO</a>";
	 exit();
	}
if(isset($_GET['yesdelete'])){
	 
	 
	$id_to_delete=$_GET['yesdelete']; 
	$sql=mysql_query("DELETE FROM products WHERE id='$id_to_delete' LIMIT 1")or die(mysql_error());
	 

	 $pictodelete=("../inventory_images/$id_to_delete.jpg");
	 if(file_exists($pictodelete)){
		 unlink($pictodelete);
		 }
		 header("location:inventory_list.php");
	     exit();
	}
?>
<?php 

if(isset($_POST['product_name'])){	
$product_name=($_POST['product_name']);
$phone=($_POST['phone']);
$price=($_POST['price']);
$category=($_POST['category']);

$details=($_POST['details']);

$sql=mysql_query("SELECT id FROM products WHERE product_name='$product_name' Limit 1");
$productMatch=mysql_num_rows($sql);
if($productMatch>0){
	echo 'Sorry you tried to place a duplicate "Product Name" into the system, <a href="inventory_list.php"> click here</a>';
	exit();
	}
	
	$sqlin = "insert into fcproducts  (prod_name,price,details,category,date_added,phone) values ('".$product_name."','".$price."','".$details."','".$category."',now(),'".$phone."')";
	mysql_query($sqlin)or die(mysql_error());
	$pid=mysql_insert_id();
	
	$newname="$pid.jpg";
	move_uploaded_file($_FILES['product_image']['tmp_name'],"../fc_images/$newname");
	header("location:inventory_list.php");
	exit();
	}
?>
<?php 

$product_list="";
$sql=mysql_query("SELECT * FROM products ORDER BY id ASC LIMIT 10");
$productCount=mysql_num_rows($sql);
if($productCount>0){
	while($row=mysql_fetch_array($sql)){
	     $id=$row["id"];	
		 $product_name=$row["prod_name"];
		 $price=$row["price"];
		 $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
		 $product_list.="<tr>"; 
		 $product_list.="<td>".$id."</td>"; 
		 $product_list.= "<td><strong>".$product_name."</strong></td>";
		 $product_list.="<td>ksh".$price. "</td>";
		 $product_list.="<td><em> Added on".  $date_added."</em></td>";
		 $product_list.="<td><a  href='inventory_edit.php?pid=$id'>edit</a></td>";
		 $product_list.="<td><a href='inventory_list.php?deleteid=$id'>delete</a><br/></td>";
		 $product_list.="</tr>";
  }
}
else{
$product_list="You have no products listed in your store yet";
}
?>
 <html>
<head>
 <title>Inventory List</title>
<link href="../css/bootstrap.css" rel="stylesheet" type="text/css">
</head>
 <body>
<nav class="nav navbar-inverse navbar-fixed-top">
 
<?php include_once("headerad.php");?>
</nav>
<br>

   <div id="dinv"><br/>
     <div align="right" style="margin-right:32px;"><a href="inventory_list.php#inventoryForm">+ Add a Product</a></div>
<div align="left" style="margin-left:24px;">
      <h2 align="center" style="color:#0C3; text-transform:uppercase;">Farm Produce</h2>
      <table width="87%" border="1" cellpadding="6" cellspacing="0" align="center">
      <tr>
      <th bgcolor="#0C3" align="left">PRODUCT ID</th>
      <th bgcolor="#0C3" align="left">Agricultural Product</th>
      <th bgcolor="#0C3" align="left">PRICE (Ksh)</th>
      <th bgcolor="#0C3" align="left">DATE ADDED</th>
      <th bgcolor="#0C3" align="left">EDIT ITEM</th>
      <th bgcolor="#0C3" align="left">DELETE ITEM</th>
      </tr>
          <?php echo  $product_list; ?> 
          </table>   
          <p><center><a href="inventory_list1.php">Click here to view all</a></center></p>
</div>
<a name="inventoryForm"id="inventoryForm"></a>
<h3 style="color:#F00; text-decoration:underline;">Add Farm Product</h3>
<form action="inventory_list.php" enctype="multipart/form-data" name="myForm" id="myForm" method="post">
<table width="90%"border="0"cellspacing="0"cellpadding="6px">
<tr>
<td width="20%" align="right">Product Name</td>
<td width="80%">
  <input type="text" name="product_name" id="product_name"size="64">
</td>
</tr>
<tr>
<td width="20%" align="right">Phone number</td>
<td width="80%">
  <input type="text" name="phone" id="phone"size="64">
</td>
</tr>
<tr>
<td align="right">Product Price</td>
<td>
   Ksh<input type="text" name="price" id="price"size="12">
</td>
</tr>
<tr>
<td align="right">Category</td>
<td>
<select name="category" id="category">
<option value="Farm Product">Farm Product</option>
<option value="Animal Product"> Animal Product</option>
</select>
</td>
</tr>

<tr>
  <td align="right">Product Details</td>
  <td>
    <textarea name="details" id="product_details" cols="64" rows="5"></textarea>
</td>
</tr>
<tr>
  <td height="60" align="right">product Image</td>
  <td>
    <input type="file" name="product_image" id="product_image">
</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>
  <input type="submit" name="add_items" id="add_items" value="Add This Item Now">
</td>
</tr>
</table>
</form>
<br/><br/><br/>
</div>
 
 </div>
 </body>
 </html>