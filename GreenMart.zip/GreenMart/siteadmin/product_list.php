<?php 
//Run a select query to get the latest items
//connect to database
include"../storescripts/connect_to_mysql.php";
$dynamicList="";
$sql=mysql_query("SELECT * FROM products ORDER BY id DESC");
$productCount=mysql_num_rows($sql);//count the output amount
if($productCount>0){
	while($row=mysql_fetch_array($sql)){
	     $id=$row["id"];	
		 $product_name=$row["product_name"];
		 $price=$row["price"];
		 $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
$dynamicList.='<table width="500" border="0" cellpadding="6">
<tr>
<td width="90"><a href="product1s.php?id='.$id.'"><img style="border:#666 1px solid"src="../inventory_images/'.$id.'.jpg" width="86" height="90"></a></td>
<td width="150" valign="top"><p>'.$product_name.'<br>
$'.$price.'<br>
<a href="product1.php?id='.$id.'">View Product Details</a></p></td>
</tr>
</table><br/> 
</td>
<td width="100" valign="top">&nbsp;</td>
</tr>
</table>';
  }
}
else{
$dynamicList="You have no new products listed in your store yet";
}
mysql_close();
?>
<html>
<head>
<title>Store Admin Page</title>
<link rel="stylesheet" href="../style/style.css" type="text/css" media="screen"/>
<style type="text/css">
<!--
body tr td h3 {
	color: #F00;
}
-->
</style>
</head>
<body>
<div id="mainWrapper" align="center">
<table border="0" width="1000px">
<tr>
<td>
<?php include_once("template_header.php");?>
</td>
</tr>
</table>
<div id="pageContent"><p>
<table width="100%"border="0">
  <tr>
    <td width="102" valign="top">&nbsp;</td>
    <td width="609" valign="top"><h3 align="center">Items Added to the store</h3>
      <p align="center"><?php echo $dynamicList; ?></p>
      </td>
      </tr>
      </table>
</div>
<table border="0" width="1000px">
<tr>
<td>
<?php include_once("../template_footer.php");?>
</td>
</tr>
</table>
</div>
 </body>
 </html>