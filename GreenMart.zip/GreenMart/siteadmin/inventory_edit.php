<?php 
//login admin
session_start();
if(!isset($_SESSION["manager"])){
	header("location:admin_login.php");
	exit();
	}
$managerID=preg_replace('#[^0-9]#i','',$_SESSION["id"]);
$manager=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["manager"]);
$password=preg_replace('#[^A-Za-z0-9]#i','',$_SESSION["password"]);
include"../sscripts/connect_to_mysql.php";
$sql=mysql_query("SELECT * FROM admin WHERE  id='$managerID' AND username='$manager' AND password='$password' LIMIT 1");
$existCount=mysql_num_rows($sql);
if($existCount == 0){
	echo "Your login session data is not on record in the database";
	exit();
		}
?>
<?php 

error_reporting(E_ALL);
ini_set('display_errors','1');
?>
<?php 

if(isset($_POST['product_name'])){	
$pid=mysql_real_escape_string($_POST['thisID']);
$product_name=mysql_real_escape_string($_POST['product_name']);
$price=mysql_real_escape_string($_POST['price']);
$category=mysql_real_escape_string($_POST['category']);

$details=mysql_real_escape_string($_POST['details']);

$sql=mysql_query("UPDATE products SET product_name='$product_name', price='$price', category='$category', subcategory='$subcategory', details='$details' WHERE id='$pid'");
	if($_FILES['product_image']['tmp_name']!=""){
	
	
	$newname="$pid.jpg";
	move_uploaded_file($_FILES['product_image']['tmp_name'],"../inventory_images/$newname");
	}
	header("location:inventory_list.php");
	exit();
}
?>
<?php 

if(isset($_GET['pid'])){
$targetID=$_GET['pid'];
$sql=mysql_query("SELECT * FROM products WHERE id='$targetID' LIMIT 1");
$productCount=mysql_num_rows($sql);
if($productCount>0){
	while($row=mysql_fetch_array($sql)){	
		 $product_name=$row["prod_name"];
		 $price=$row["price"];
		 $category=$row["category"];
		
		 $details=$row["details"];
		 $date_added=strftime("%b %d, %Y",strtotime($row["date_added"]));
  }
}
else{
echo "Sorry that product doesn`t exist!!!";
exit();
}
}
?>
 <html>
<head>
 <title>Inventory List</title>
<link rel="stylesheet" href="../style/style.css" type="text
/css" media="screen"/>
</head>
 <body>
 
   <div id="idisplay"><br/>
     <div align="right" style="margin-right:32px;"><a href="inventory_list.php#inventoryForm">+ Add New Inventory Item</a></div>
<div align="left" style="margin-left:24px;">
      <h2>Inventory List</h2>     
</div>
<a name="inventoryForm"id="inventoryForm"></a>
<h3>Add New Inventory Item Form</h3>
<form action="inventory_edit.php" enctype="multipart/form-data" name="myForm" id="myForm" method="post">
<table width="90%"border="0"cellspacing="0"cellpadding="6px">
<tr>
<td width="20%" align="right">Product Name</td>
<td width="80%">
  <input type="text" name="product_name" id="product_name" value="<?php echo $product_name; ?>">
</td>
</tr>
<tr>
<td align="right">Product Price</td>
<td>
 
     <input type="text" name="price" id="price"size="12" value="<?php echo $price; ?>">
</td>
</tr>
<tr>
<td align="right">Category</td>
<td>
<select name="category" id="category">
<option value="Farm Product">Farm Product</option>
<option value="Animal Product"> Animal Product</option>
</select>
</td>
</tr>

<tr>
  <td align="right">Product Details</td>
  <td>
    <textarea name="details" id="product_details"  rows="5"><?php echo $details; ?></textarea>
</td>
</tr>
<tr>
  <td height="60" align="right">product Image</td>
  <td>
    <input type="file" name="product_image" id="product_image">
</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>
<input name="thisID" type="hidden" value="<?php echo $targetID; ?>">
  <input type="submit" name="add_items" id="add_items" value="Edit Item ">
</td>
</tr>
</table>
</form>
<br/>
<a href="inventory_list.php"><-Go back</a>
<br/>
<br/>
</div>
 
 </div>
 </body>
 </html>