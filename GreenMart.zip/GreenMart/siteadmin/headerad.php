<head>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">

</head>

<div class="container-fluid">
    <div class="navbar-header">
   
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="inventory_list.php">AD farm product</a></li>
        <li><a href="Aggrovet.php">Add farmcare product</a></li>
        <li><a href="logout.php">logout</a></li>
        
      </ul>
      
    </div>
  </div>